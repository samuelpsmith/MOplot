This is a simple script to plot and annotate MO's

I use seaborn, and one can choose between plotting simple categorical compound vs energy level, or try to use swarmplot to dodge/jitter the points to show degenerate energy levels side by side.

I think the former looks better because the latter is asymmetric, and so it is enabled by default.

Finally, a simple loop annotates energy levels with labels from the csv. Degeneracies of up to 4 are suppported. To change how close degenerate levels are, you can change the paramter degen, which is in eV. 

The MTPP file is included as an example of how to format data. 